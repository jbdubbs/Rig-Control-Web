RigControl Web — "Panel" icon set
====================================

logo/
  logo-1024.png ......... full-resolution app logo (1024x1024)
  logo.svg .............. vector master (scale to any size)
  lockup-horizontal.png/.svg ... wordmark lockup for README headers, sites
windows/
  icon.ico .............. multi-resolution (16/24/32/48/64/128/256), PNG-compressed
                          electron-builder: put at build/icon.ico
macos/
  icon.icns ............. 16/32/64/128/256/512/1024
                          electron-builder: put at build/icon.icns
linux/
  16x16.png ... 1024x1024.png
                          electron-builder: build/icons/ (AppImage); also for .desktop hicolor themes
web/
  favicon.ico ........... 16/32/48 favicon
  favicon-16.png, favicon-32.png
  apple-touch-icon.png .. 180x180
  icon-192.png, icon-512.png ... PWA manifest icons

Small sizes (16/24/32/48) use a simplified mark so the icon stays legible in taskbars and tabs.
License: do whatever you like with these (generated artwork, no restrictions).
